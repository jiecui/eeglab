% 'r'	- Red
% 'g'	- Green
% 'b'	- Blue
% 'c'	- Cyan
% 'm'	- Magenta
% 'y'	- Yellow
% 'k'	- Black
% 'w'	- White

function c = getcolorcellerps
c     = {'k' 'r' 'b' 'g' 'c' 'm' 'y' 'w' };
return